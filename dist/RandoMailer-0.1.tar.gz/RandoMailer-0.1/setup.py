# setup.py

from setuptools import setup, find_packages

setup(
    name='RandoMailer',
    version='0.1',
    packages=find_packages(),
    install_requires=[],
    author='Akash Desai',
    author_email='Akashh2151@gmail.com', 
    description='A package for generating random emails',
)
